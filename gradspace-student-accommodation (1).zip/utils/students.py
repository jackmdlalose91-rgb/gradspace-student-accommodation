import streamlit as st
import pandas as pd
import os

DATA_FILE = "data/students.csv"
UPLOAD_FOLDER = "uploads/student_photos"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs("data", exist_ok=True)

def load_data():
    if os.path.exists(DATA_FILE):
        return pd.read_csv(DATA_FILE)
    return pd.DataFrame(columns=[
        "Name", "Suite", "Room", "Entry Date", "Exit Date",
        "Monthly Rent", "Rent Paid", "Electricity", "Water",
        "Internet", "Other", "Total Due", "Next of Kin",
        "Kin Contact", "Home Address", "Photo"
    ])

def save_data(df):
    df.to_csv(DATA_FILE, index=False)

def student_module():
    st.header("📋 Student Records")

    df = load_data()

    with st.form("add_student"):
        name = st.text_input("Student Name")
        suite = st.selectbox("Suite", ["Gradspace Suite 1", "Gradspace Suite 2"])
        room = st.text_input("Room Number (any)")
        entry_date = st.date_input("Entry Date")
        exit_date = st.date_input("Exit Date")
        rent = st.number_input("Monthly Rent", min_value=0, step=50)
        rent_paid = st.selectbox("Rent Paid", ["No", "Yes"])
        electricity = st.number_input("Electricity Bill", min_value=0, step=10)
        water = st.number_input("Water Bill", min_value=0, step=10)
        internet = st.number_input("Internet Bill", min_value=0, step=10)
        other = st.number_input("Other Utilities", min_value=0, step=10)
        next_of_kin = st.text_input("Next of Kin")
        kin_contact = st.text_input("Next of Kin Contact")
        home_address = st.text_area("Home Address")
        photo = st.file_uploader("Upload Profile Photo", type=["jpg", "png"])

        submitted = st.form_submit_button("Add Student")

        if submitted and name:
            photo_path = ""
            if photo:
                photo_path = os.path.join(UPLOAD_FOLDER, photo.name)
                with open(photo_path, "wb") as f:
                    f.write(photo.getbuffer())

            total_due = 0 if rent_paid == "Yes" else rent
            total_due += electricity + water + internet + other

            new_row = {
                "Name": name, "Suite": suite, "Room": room,
                "Entry Date": entry_date, "Exit Date": exit_date,
                "Monthly Rent": rent, "Rent Paid": rent_paid,
                "Electricity": electricity, "Water": water,
                "Internet": internet, "Other": other, "Total Due": total_due,
                "Next of Kin": next_of_kin, "Kin Contact": kin_contact,
                "Home Address": home_address, "Photo": photo_path
            }
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
            save_data(df)
            st.success(f"✅ Record added for {name}")

    if not df.empty:
        st.dataframe(df)

        to_delete = st.selectbox("Select student to delete", [""] + df["Name"].tolist())
        if st.button("Delete Student") and to_delete:
            df = df[df["Name"] != to_delete]
            save_data(df)
            st.warning(f"🗑️ Deleted {to_delete}")
    else:
        st.info("No records yet. Add students above.")
