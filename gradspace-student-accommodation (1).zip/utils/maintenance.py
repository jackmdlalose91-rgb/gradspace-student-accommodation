import streamlit as st
import pandas as pd
import os

DATA_FILE = "data/maintenance.csv"
UPLOAD_FOLDER = "uploads/maintenance_photos"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs("data", exist_ok=True)

def load_data():
    if os.path.exists(DATA_FILE):
        return pd.read_csv(DATA_FILE)
    return pd.DataFrame(columns=[
        "Task", "Assigned To", "Cost", "Date", "Notes", "Photo"
    ])

def save_data(df):
    df.to_csv(DATA_FILE, index=False)

def maintenance_module():
    st.header("🛠️ Maintenance & Staff Records")

    df = load_data()

    with st.form("add_task"):
        task = st.text_input("Task / Job Description")
        assigned = st.text_input("Assigned To (worker/staff)")
        cost = st.number_input("Cost", min_value=0, step=10)
        date = st.date_input("Date")
        notes = st.text_area("Notes")
        photo = st.file_uploader("Upload Evidence Photo", type=["jpg", "png"])
        submitted = st.form_submit_button("Add Task")

        if submitted and task:
            photo_path = ""
            if photo:
                photo_path = os.path.join(UPLOAD_FOLDER, photo.name)
                with open(photo_path, "wb") as f:
                    f.write(photo.getbuffer())

            new_row = {
                "Task": task, "Assigned To": assigned,
                "Cost": cost, "Date": date,
                "Notes": notes, "Photo": photo_path
            }
            df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
            save_data(df)
            st.success("✅ Task Added")

    if not df.empty:
        st.dataframe(df)

        to_delete = st.selectbox("Select task to delete", [""] + df["Task"].tolist())
        if st.button("Delete Task") and to_delete:
            df = df[df["Task"] != to_delete]
            save_data(df)
            st.warning(f"🗑️ Deleted {to_delete}")
    else:
        st.info("No maintenance records yet. Add tasks above.")
