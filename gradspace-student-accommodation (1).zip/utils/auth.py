import streamlit as st

USERS = {
    "admin": {"password": "admin123", "role": "Admin"},
    "manager1": {"password": "manager123", "role": "Manager"},
}

def login():
    st.sidebar.title("🔑 Login")

    username = st.sidebar.text_input("Username")
    password = st.sidebar.text_input("Password", type="password")
    login_btn = st.sidebar.button("Login")

    if login_btn:
        if username in USERS and USERS[username]["password"] == password:
            st.session_state["logged_in"] = True
            st.session_state["username"] = username
            st.session_state["role"] = USERS[username]["role"]
            st.sidebar.success(f"✅ Logged in as {username} ({USERS[username]['role']})")
            return True
        else:
            st.sidebar.error("❌ Invalid username or password")
            return False

    if st.session_state.get("logged_in", False):
        st.sidebar.info(f"👤 {st.session_state['username']} ({st.session_state['role']})")
        return True

    return False

def logout():
    if st.sidebar.button("🚪 Logout"):
        st.session_state.clear()
        st.sidebar.success("Logged out successfully")
