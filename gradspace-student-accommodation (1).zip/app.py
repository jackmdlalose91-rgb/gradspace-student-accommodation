import streamlit as st
from utils.auth import login, logout
from utils.students import student_module
from utils.maintenance import maintenance_module

st.set_page_config(page_title="Gradspace Student Accommodation", layout="wide")

if not login():
    st.stop()

logout()

st.title("🏠 Gradspace Student Accommodation Tracker")

menu = st.sidebar.radio("📂 Menu", ["Students", "Maintenance"])

if menu == "Students":
    student_module()
elif menu == "Maintenance":
    maintenance_module()
